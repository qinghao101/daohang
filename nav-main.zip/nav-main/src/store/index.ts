// Copyright @ 2018-2021 xiejiahe. All rights reserved. MIT license.

import { websiteList as w } from '../utils'

export const websiteList = w
