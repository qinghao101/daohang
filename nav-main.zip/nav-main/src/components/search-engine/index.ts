
export enum SearchType {
  All = 1,
  Title,
  Desc,
  Url,
  Current
}
